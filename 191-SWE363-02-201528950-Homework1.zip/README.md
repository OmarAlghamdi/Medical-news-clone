# SWE 363 Homework 1 | [Medical News Today](MedicalNewsToday.com) clone
This is a clone of Medical New Today.

the clone is just for the home page and the rest of the created pages does not necessarily reflect the real design.

[Link to the live version]()